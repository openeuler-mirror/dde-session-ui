<?xml version="1.0" ?><!DOCTYPE TS><TS language="bo" version="2.1">
    <context>
        <name>desktop</name>
        <message>
            <location filename="Desktop Entry]GenericName" line="0"/>
            <location filename="Desktop Entry]Name" line="0"/>
            <source>Show Desktop</source>
            <translation>མངོན་སྟོན་ཅོག་ངོས།</translation>
        </message>
        <message>
            <location filename="Desktop Entry]Comment" line="0"/>
            <source>Show desktop or show windows</source>
            <translation>ཅོག་ངོས་སམ་སྒེའུ་ཁུང་ཚང་མ་མངོན་སྟོན་བྱེད།</translation>
        </message>
    </context>
</TS>
<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk" version="2.1">
    <context>
        <name>desktop</name>
        <message>
            <location filename="Desktop Entry]GenericName" line="0"/>
            <location filename="Desktop Entry]Name" line="0"/>
            <source>Show Desktop</source>
            <translation>Zobraziť plochu</translation>
        </message>
        <message>
            <location filename="Desktop Entry]Comment" line="0"/>
            <source>Show desktop or show windows</source>
            <translation>Zobraziť plochu alebo zobraziť okná</translation>
        </message>
    </context>
</TS>
<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr" sourcelanguage="en" version="2.1">
<context>
    <name>Bubble</name>
    <message>
        <location filename="../dde-osd/notification/bubble.cpp" line="309"/>
        <source>1 new message</source>
        <translation>1 нова порука</translation>
    </message>
</context>
<context>
    <name>BubbleItem</name>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="221"/>
        <source>Just Now</source>
        <translation>Управо сад</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="223"/>
        <source>%1 minutes ago</source>
        <translation>Пре %1 минута</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="225"/>
        <source>%1 hours ago</source>
        <translation>Пре %1 сата/и</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="228"/>
        <source>Yesterday </source>
        <translation>Јуче</translation>
    </message>
</context>
<context>
    <name>Content</name>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="228"/>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="229"/>
        <source>Confirm</source>
        <translation>Потврди</translation>
    </message>
</context>
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="330"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="367"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="391"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="527"/>
        <source>Shut down</source>
        <translation>Искључи</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="332"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="369"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="396"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="530"/>
        <source>Reboot</source>
        <translation>Поново покрени</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="392"/>
        <source>Are you sure you want to shut down?</source>
        <translation>Заиста желите да искључите?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="397"/>
        <source>Are you sure you want to reboot?</source>
        <translation>Заиста желите да поново покренете?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="338"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="401"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="542"/>
        <source>Log out</source>
        <translation>Одјави се</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="402"/>
        <source>Are you sure you want to log out?</source>
        <translation>Заиста желите да се одјавите?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="334"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="533"/>
        <source>Suspend</source>
        <translation>Обустави</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="326"/>
        <source>The programs are preventing the computer from shutting down / hibernation, and forcing shut down / hibernate may cause data loss.</source>
        <translation>Програми спречавају искључивање / хибернацију и принудно искључивање / хибернација може изазвати губитак података.</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="327"/>
        <source>To close the program, Click Cancel, and then close the program.</source>
        <translation>Прво кликни на Откажи, затим затвори програм.</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="336"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="536"/>
        <source>Hibernate</source>
        <translation>Хибернација</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="539"/>
        <source>Lock</source>
        <translation>Закључај</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="546"/>
        <source>Switch user</source>
        <translation>Промени корисника</translation>
    </message>
</context>
<context>
    <name>DMemoryWarningDialog</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="49"/>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="86"/>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="51"/>
        <source>Release</source>
        <translation>Ослободи</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="54"/>
        <source>This application will be ended, please make sure your data has been saved!</source>
        <translation>Овај програм ће бити окончан, молимо проверите да ли су ваши подаци сачувани!</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="55"/>
        <source>Please save your document, text and spreadsheet</source>
        <translation>Молимо сачувајте ваш документ, текст и табелу</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="87"/>
        <source>Continue</source>
        <translation>Настави</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="105"/>
        <source>Insufficient system memory, please end some applications to avoid getting stuck.</source>
        <translation>Недовољно системске меморије, молимо окончајте неке програме да избегнете заглављивање.</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="217"/>
        <source>Continue to run %1, %2MB memory is required</source>
        <translation>Настави процес %1, %2MB меморије је потребно</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="220"/>
        <source>Continue to open browser tab, %1MB memory is required</source>
        <translation>Настави са отварањем картице прегледача, %1MB меморије је потребно</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="223"/>
        <source>To continue the operation, %1MB memory is required</source>
        <translation>Да наставите рад потребно је, %1MB меморије</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="229"/>
        <source>Your current memory is sufficient enough, continue to run %1?</source>
        <translation>Ваша тренутна меморија је довољна, наставити покретање %1?</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="232"/>
        <source>Your current memory is sufficient enough, continue to open browser tab?</source>
        <translation>Количина тренутне меморије је довољна, наставити са отварањем картице прегледача?</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="235"/>
        <source>Your current memory is sufficient enough, continue the operation?</source>
        <translation>Количина тренутне меморије је довољна, наставити са операцијом?</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="30"/>
        <source>Updates downloaded, restart to update?</source>
        <translation>Ажурирања су преузета. Поново покренути рачунар и ажирирати?</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="33"/>
        <source>Remind Later</source>
        <translation>Подсети касније</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="34"/>
        <source>Not Now</source>
        <translation>Не сад</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="35"/>
        <source>Update Now</source>
        <translation>Ажурирај сад</translation>
    </message>
</context>
<context>
    <name>DisplayModeProvider</name>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="249"/>
        <source>Only on %1</source>
        <translation>Само на %1</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="251"/>
        <source>Duplicate</source>
        <translation>Умножи</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="253"/>
        <source>Extend</source>
        <translation>Прошири</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="54"/>
        <source>Please don&apos;t power off or unplug your machine</source>
        <translation>Немојте искључивати рачунар и довод струје</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="136"/>
        <source>Installing updates %1%, please wait...</source>
        <translation>Инсталирање ажурирања %1%, сачекајте...</translation>
    </message>
</context>
<context>
    <name>GreeterWorkek</name>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="93"/>
        <source>Domain account</source>
        <translation>Доменски налог</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="249"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>Време за верификацију отиска прста је истекло, унесите лозинку ручно</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="264"/>
        <source>Failed to match fingerprint</source>
        <translation>Неподударање отиска прста</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="282"/>
        <source>Wrong Password</source>
        <translation>Погрешна лозинка</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="287"/>
        <source>The domain account or password is not correct. Please enter again.</source>
        <translation>Погрешан доменски налог или лозинка. Молимо поново унесите.</translation>
    </message>
</context>
<context>
    <name>InhibitWarnView</name>
    <message>
        <location filename="../dde-shutdown/view/inhibitwarnview.cpp" line="66"/>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
</context>
<context>
    <name>KBLayoutIndicator</name>
    <message>
        <location filename="../dde-osd/kblayoutindicator.cpp" line="161"/>
        <source>Add keyboard layout</source>
        <translation>Додај распоред тастатуре</translation>
    </message>
</context>
<context>
    <name>LockWorker</name>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="98"/>
        <source>Domain account</source>
        <translation>Доменски налог</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="221"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>Време за верификацију отиска прста је истекло, унесите лозинку ручно</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="239"/>
        <source>Failed to match fingerprint</source>
        <translation>Неподударање отиска прста</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="274"/>
        <source>Wrong Password</source>
        <translation>Погрешна лозинка</translation>
    </message>
</context>
<context>
    <name>MultiUsersWarningView</name>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="44"/>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="129"/>
        <source>The above users are still logged in and data will be lost due to reboot, are you sure you want to reboot?</source>
        <translation>Горе наведени корисници су и даље пријављени и њихови несачувани подаци ће нестати. Заиста желите да поново покренете?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="123"/>
        <source>The above users are still logged in and data will be lost due to shutdown, are you sure you want to shut down?</source>
        <translation>Горе наведени корисници су и даље пријављени и њихови несачувани подаци ће нестати. Заиста желите да искључите?</translation>
    </message>
</context>
<context>
    <name>NetworkSecretDialog</name>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="46"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="52"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="62"/>
        <source>Password</source>
        <translation>Лозинка</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="47"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="48"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="49"/>
        <source>Key</source>
        <translation>Кључ</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="50"/>
        <source>key</source>
        <translation>кључ</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="58"/>
        <source>Private Pwd</source>
        <translation>Лична лозинка</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="61"/>
        <source>Proxy Password</source>
        <translation>Лозинка посредника</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="63"/>
        <source>Group Password</source>
        <translation>Лозинка групе</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="105"/>
        <source>Password required to connect &lt;font color=&quot;%1&quot;&gt;%2&lt;/font&gt;</source>
        <translation>Лозинка је потребна за повезивање &lt;font color=&quot;%1&quot;&gt;%2&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="174"/>
        <source>Wrong password, please enter again!</source>
        <translation>Погрешна лозинка! Унесите поново.</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="114"/>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="114"/>
        <source>Connect</source>
        <translation>Повежи се</translation>
    </message>
</context>
<context>
    <name>NotificationsPlugin</name>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="71"/>
        <source>Notification Center</source>
        <translation>Обавештајни центар</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="91"/>
        <source>%1 Notifications</source>
        <translation>%1 Обавештења</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="93"/>
        <source>No messages</source>
        <translation>Нема порука</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="239"/>
        <source>Turn off DND mode</source>
        <translation>Искључи НУ режим</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="239"/>
        <source>Turn on DND mode</source>
        <translation>Укључи НУ режим</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="246"/>
        <source>Notification settings</source>
        <translation>Подешавање обавештења</translation>
    </message>
</context>
<context>
    <name>NotifyCenterWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifycenterwidget.cpp" line="89"/>
        <source>Notification Center</source>
        <translation>Обавештајни центар</translation>
    </message>
</context>
<context>
    <name>NotifyWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifywidget.cpp" line="40"/>
        <source>No system notifications</source>
        <translation>Нема системских обавештења</translation>
    </message>
</context>
<context>
    <name>OSDProvider</name>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="47"/>
        <source>Window effect enabled</source>
        <translation>Ефекти укључени</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="48"/>
        <source>Window effect disabled</source>
        <translation>Ефекти искључени</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="49"/>
        <source>Failed to enable window effects</source>
        <translation>Неуспешно укључивање ефеката</translation>
    </message>
</context>
<context>
    <name>PinCodeDialog</name>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="39"/>
        <source>The PIN for connecting to the Bluetooth device is:</source>
        <translation>ПИН код за повезивање са Блутут уређајем је:</translation>
    </message>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="47"/>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="49"/>
        <source>Confirm</source>
        <translation>Потврди</translation>
    </message>
</context>
<context>
    <name>ProcessInfoModel</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/processinfomodel.cpp" line="111"/>
        <source>End</source>
        <translation>Окончај</translation>
    </message>
</context>
<context>
    <name>SuspendDialog</name>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="39"/>
        <source>External monitor detected, suspend?</source>
        <translation>Спољашњи екран је откривен, обустави?</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="39"/>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="61"/>
        <source>%1s</source>
        <translation>%1s</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="50"/>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="50"/>
        <source>Suspend</source>
        <translation>Обустави</translation>
    </message>
</context>
<context>
    <name>SystemMonitor</name>
    <message>
        <location filename="../dde-shutdown/view/systemmonitor.cpp" line="45"/>
        <source>Start system monitor</source>
        <translation>Покрени праћење система</translation>
    </message>
</context>
<context>
    <name>TimeWidget</name>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="69"/>
        <source>hh:mm</source>
        <translation>hh:mm</translation>
    </message>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="70"/>
        <source>yyyy-MM-dd dddd</source>
        <translation>dddd dd-MM-yyyy</translation>
    </message>
</context>
<context>
    <name>TouchscreenSetting</name>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="43"/>
        <source>Select your touch screen</source>
        <translation>Изабери екран на додир</translation>
    </message>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="53"/>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="54"/>
        <source>Confirm</source>
        <translation>Потврди</translation>
    </message>
</context>
<context>
    <name>UpdateContent</name>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="44"/>
        <source>Welcome, system updated successfully</source>
        <translation>Добро дошли, систем је ажуриран успешно</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="45"/>
        <source>Current Edition:</source>
        <translation>Тренутно издање:</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="46"/>
        <source>Enter</source>
        <translation>Улаз</translation>
    </message>
</context>
<context>
    <name>WMChooser</name>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="57"/>
        <source>Effect Mode</source>
        <translation>Режим ефеката</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="60"/>
        <source>Normal Mode</source>
        <translation>Обичан режим</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="68"/>
        <source>It has detected that you are using a virtual machine, which will affect the system performance and operation experience, for a smooth experience, Normal Mode is recommended</source>
        <translation>Систем је препознао да користите виртуелну машину што ће утицати на перформансе система и корисничко искуство. За глатко корисничко искуство препоручено је да користите Обичан режим.</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="71"/>
        <source>Effect Mode: Have a delicate experience. Normal Mode: Enjoy the fast performance</source>
        <translation>Режим Ефеката: За деликатан доживљај. Обичан Режим: Уживајте у брзим перформансама</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="64"/>
        <source>Friendly Reminder</source>
        <translation>Пријатељски подсетник</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="37"/>
        <source>Kindly Reminder</source>
        <translation>Љубазно подсећамо</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="38"/>
        <source>This application cannot run without window effect</source>
        <translation>Овај програм се не може покренути без ефеката прозора</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="42"/>
        <source>OK</source>
        <translation>У реду</translation>
    </message>
</context>
<context>
    <name>Window</name>
    <message>
        <location filename="../dde-lowpower/window.cpp" line="39"/>
        <source>Low battery, please plug in</source>
        <translation>Батерија при крају. Укључите пуњач.</translation>
    </message>
</context>
</TS>
For asking questions, see:

* [Feedback](http://feedback.deepin.org/)
* [BBS](http://bbs.deepin.org/)
<?xml version="1.0" ?><!DOCTYPE TS><TS language="fa" sourcelanguage="en" version="2.1">
<context>
    <name>Bubble</name>
    <message>
        <location filename="../dde-osd/notification/bubble.cpp" line="309"/>
        <source>1 new message</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BubbleItem</name>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="198"/>
        <source>Just Now</source>
        <translation>همین حالا</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="200"/>
        <source>%1 minutes ago</source>
        <translation>%1 دقیقه پیش</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="202"/>
        <source>%1 hours ago</source>
        <translation>%1 ساعت پیش</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="205"/>
        <source>Yesterday </source>
        <translation>دیروز</translation>
    </message>
</context>
<context>
    <name>Content</name>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="224"/>
        <source>Cancel</source>
        <translation>انصراف</translation>
    </message>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="225"/>
        <source>Confirm</source>
        <translation>تایید</translation>
    </message>
</context>
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="330"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="367"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="391"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="527"/>
        <source>Shut down</source>
        <translation>خاموش شدن</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="332"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="369"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="396"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="530"/>
        <source>Reboot</source>
        <translation>راه اندازی مجدد</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="392"/>
        <source>Are you sure you want to shut down?</source>
        <translation>آیا از خاموشی مطمئن هستید ؟</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="397"/>
        <source>Are you sure you want to reboot?</source>
        <translation>آیا از  راه اندازی مجدد مطمئن هستید ؟</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="338"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="401"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="542"/>
        <source>Log out</source>
        <translation>خارج شدن از حساب کاربری</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="402"/>
        <source>Are you sure you want to log out?</source>
        <translation>آیا از خارج شدن مطمئن هستید ؟</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="334"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="533"/>
        <source>Suspend</source>
        <translation>معلق کردن</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="326"/>
        <source>The programs are preventing the computer from shutting down / hibernation, and forcing shut down / hibernate may cause data loss.</source>
        <translation>این برنامه‌ها مانع از خاموش شدن کامپیوتر و هایبرنت شدن  می‌شوند و مجبور کردن به هایبرنت یا خاموش کردن ممکن است باعث از دست رفتن داده‌ها شود .</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="327"/>
        <source>To close the program, Click Cancel, and then close the program.</source>
        <translation>برای بستن برنامه ، روی لغو کلیک کرده و سپس برنامه را ببندید.</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="336"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="536"/>
        <source>Hibernate</source>
        <translation>هایبرنت</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="539"/>
        <source>Lock</source>
        <translation>قفل</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="546"/>
        <source>Switch user</source>
        <translation>تغییر حساب کاربری</translation>
    </message>
</context>
<context>
    <name>DMemoryWarningDialog</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="49"/>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="86"/>
        <source>Cancel</source>
        <translation>انصراف</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="51"/>
        <source>Release</source>
        <translation>انتشار</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="54"/>
        <source>This application will be ended, please make sure your data has been saved!</source>
        <translation>این برنامه به پایان خواهد رسید , لطفا ً مطمئن شوید که داده‌هایتان ذخیره شده‌است !</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="55"/>
        <source>Please save your document, text and spreadsheet</source>
        <translation>لطفاً سند ، متن و صفحه گسترده خود را ذخیره کنید</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="87"/>
        <source>Continue</source>
        <translation>ادامه</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="105"/>
        <source>Insufficient system memory, please end some applications to avoid getting stuck.</source>
        <translation>حافظه سیستم ناکافی است، لطفا ً به برخی برنامه‌ها پایان دهید تا از گیر  کردن جلوگیری کنید .</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="217"/>
        <source>Continue to run %1, %2MB memory is required</source>
        <translation>برای  اجرای %1 ادامه دهید ،   %2MB حافظه لازم است</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="220"/>
        <source>Continue to open browser tab, %1MB memory is required</source>
        <translation>برای ادامه ی باز کردن تب مرورگر  %1MB حافظه نیاز است</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="223"/>
        <source>To continue the operation, %1MB memory is required</source>
        <translation>برای ادامه انجام عملیات به %1MB حافظه نیاز است </translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="229"/>
        <source>Your current memory is sufficient enough, continue to run %1?</source>
        <translation>حافظه فعلی شما به اندازه کافی است،  آیا می خواهید تا %1 اجرا شود؟</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="232"/>
        <source>Your current memory is sufficient enough, continue to open browser tab?</source>
        <translation>حافظه فعلی شما به اندازه کافی است،  آیا می خواهید تب مرورگر باز شود؟</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="235"/>
        <source>Your current memory is sufficient enough, continue the operation?</source>
        <translation>حافظه فعلی شما به اندازه کافی است،  آیا می خواهید  ادامه عملیات اجرا شود؟</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="30"/>
        <source>Updates downloaded, restart to update?</source>
        <translation>به روزرسانی ها دانلود شده ، برای به روزرسانی مجدداً راه اندازی می شوند؟</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="33"/>
        <source>Remind Later</source>
        <translation>بعدا ً به من یادآوری کن</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="34"/>
        <source>Not Now</source>
        <translation>الان نه</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="35"/>
        <source>Update Now</source>
        <translation>اکنون بروزرسانی کن</translation>
    </message>
</context>
<context>
    <name>DisplayModeProvider</name>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="264"/>
        <source>Customize</source>
        <translation>شخصی سازی</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="266"/>
        <source>Duplicate</source>
        <translation>تکراری</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="268"/>
        <source>Extend</source>
        <translation>گسترش</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="54"/>
        <source>Please don&apos;t power off or unplug your machine</source>
        <translation>لطفاً دستگاه خود را خاموش و یا از برق جدا نکنید</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="136"/>
        <source>Installing updates %1%, please wait...</source>
        <translation>در حال نصب بروزرسانی ها %1% ، لطفا صبر کنید...</translation>
    </message>
</context>
<context>
    <name>GreeterWorkek</name>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="93"/>
        <source>Domain account</source>
        <translation>حساب دامنه</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="249"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>تایید اثر انگشت منقضی شد , لطفا ً رمزعبور خود را دستی وارد کنید</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="264"/>
        <source>Failed to match fingerprint</source>
        <translation>تطابق اثر انگشت ناموفق بود</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="282"/>
        <source>Wrong Password</source>
        <translation>رمزعبور اشتباه است</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="287"/>
        <source>The domain account or password is not correct. Please enter again.</source>
        <translation>حساب دامنه یا رمزعبور صحیح نیست. لطفا دوباره وارد کنید</translation>
    </message>
</context>
<context>
    <name>InhibitWarnView</name>
    <message>
        <location filename="../dde-shutdown/view/inhibitwarnview.cpp" line="66"/>
        <source>Cancel</source>
        <translation>انصراف</translation>
    </message>
</context>
<context>
    <name>KBLayoutIndicator</name>
    <message>
        <location filename="../dde-osd/kblayoutindicator.cpp" line="159"/>
        <source>Add keyboard layout</source>
        <translation>اضافه کردن طرح بندی صفحه کلید</translation>
    </message>
</context>
<context>
    <name>LockWorker</name>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="98"/>
        <source>Domain account</source>
        <translation>حساب دامنه</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="221"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>تایید اثر انگشت منقضی شد , لطفا ً رمزعبور خود را دستی وارد کنید</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="239"/>
        <source>Failed to match fingerprint</source>
        <translation>تطابق اثر انگشت ناموفق بود</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="274"/>
        <source>Wrong Password</source>
        <translation>رمزعبور اشتباه است</translation>
    </message>
</context>
<context>
    <name>MultiUsersWarningView</name>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="44"/>
        <source>Cancel</source>
        <translation>انصراف</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="129"/>
        <source>The above users are still logged in and data will be lost due to reboot, are you sure you want to reboot?</source>
        <translation>کاربران بالا هنوز  داخل  سیستم هستند و داده‌ها به دلیل راه اندازی مجدد از دست خواهند رفت , آیا مطمئنید که می‌خواهید سیستم راه اندازی مجدد شود ؟</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="123"/>
        <source>The above users are still logged in and data will be lost due to shutdown, are you sure you want to shut down?</source>
        <translation>کاربران بالا هنوز  داخل  سیستم هستند و داده‌ها به دلیل خاموش شدن از دست خواهند رفت , آیا مطمئنید که می‌خواهید سیستم خاموش شود ؟</translation>
    </message>
</context>
<context>
    <name>NetworkSecretDialog</name>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="46"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="52"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="62"/>
        <source>Password</source>
        <translation>رمزعبور</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="47"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="48"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="49"/>
        <source>Key</source>
        <translation>کلید</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="50"/>
        <source>key</source>
        <translation>کلید</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="58"/>
        <source>Private Pwd</source>
        <translation>پسورد شخصی</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="61"/>
        <source>Proxy Password</source>
        <translation>رمز عبور پروکسی</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="63"/>
        <source>Group Password</source>
        <translation>رمزعبور گروه</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="105"/>
        <source>Password required to connect &lt;font color=&quot;%1&quot;&gt;%2&lt;/font&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="174"/>
        <source>Wrong password, please enter again!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="114"/>
        <source>Cancel</source>
        <translation>انصراف</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="114"/>
        <source>Connect</source>
        <translation>اتصال</translation>
    </message>
</context>
<context>
    <name>NotificationsPlugin</name>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="67"/>
        <source>Notification Center</source>
        <translation>مرکز اعلان</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="87"/>
        <source>%1 Notifications</source>
        <translation>%1 اعلان ها </translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="89"/>
        <source>No messages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="255"/>
        <source>Turn off DND mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="255"/>
        <source>Turn on DND mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="262"/>
        <source>Notification settings</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>NotifyCenterWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifycenterwidget.cpp" line="88"/>
        <source>Notification Center</source>
        <translation>مرکز اعلان</translation>
    </message>
</context>
<context>
    <name>NotifyWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifywidget.cpp" line="40"/>
        <source>No system notifications</source>
        <translation>هیچ اعلان سیستمی وجود ندارد</translation>
    </message>
</context>
<context>
    <name>OSDProvider</name>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="47"/>
        <source>Window effect enabled</source>
        <translation>جلوه های پنجره فعال شد</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="48"/>
        <source>Window effect disabled</source>
        <translation>جلوه های پنجره غیرفعال شد</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="49"/>
        <source>Failed to enable window effects</source>
        <translation>عدم توانایی در اعمال جلوه های پنجره</translation>
    </message>
</context>
<context>
    <name>ProcessInfoModel</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/processinfomodel.cpp" line="111"/>
        <source>End</source>
        <translation>پایان</translation>
    </message>
</context>
<context>
    <name>SuspendDialog</name>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="39"/>
        <source>External monitor detected, suspend?</source>
        <translation>مانیتور خارجی شناسایی شد ، تعلیق شود؟</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="39"/>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="61"/>
        <source>%1s</source>
        <translation>%1s</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="50"/>
        <source>Cancel</source>
        <translation>انصراف</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="50"/>
        <source>Suspend</source>
        <translation>معلق کردن</translation>
    </message>
</context>
<context>
    <name>SystemMonitor</name>
    <message>
        <location filename="../dde-shutdown/view/systemmonitor.cpp" line="45"/>
        <source>Start system monitor</source>
        <translation>آغاز پایش سیستم</translation>
    </message>
</context>
<context>
    <name>TimeWidget</name>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="69"/>
        <source>hh:mm</source>
        <translation>hh:mm</translation>
    </message>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="70"/>
        <source>yyyy-MM-dd dddd</source>
        <translation>yyyy-MM-dd dddd</translation>
    </message>
</context>
<context>
    <name>TouchscreenSetting</name>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="45"/>
        <source>Select your touch screen</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="51"/>
        <source>Cancel</source>
        <translation>انصراف</translation>
    </message>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="52"/>
        <source>Confirm</source>
        <translation>تایید</translation>
    </message>
</context>
<context>
    <name>UpdateContent</name>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="44"/>
        <source>Welcome, system updated successfully</source>
        <translation>خوش آمدید ، سیستم با موفقیت به روز شد</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="45"/>
        <source>Current Edition:</source>
        <translation>نسخه جاری</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="46"/>
        <source>Enter</source>
        <translation>وارد شدن</translation>
    </message>
</context>
<context>
    <name>WMChooser</name>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="57"/>
        <source>Effect Mode</source>
        <translation>حالت افکت</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="60"/>
        <source>Normal Mode</source>
        <translation>حالت معمولی</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="68"/>
        <source>It has detected that you are using a virtual machine, which will affect the system performance and operation experience, for a smooth experience, Normal Mode is recommended</source>
        <translation>مشخص شده‌است که شما از یک ماشین مجازی استفاده می‌کنید که بر عملکرد سیستم و تجربه عملیات تاثیر می‌گذارد , برای یک تجربه روان , حالت عادی توصیه می‌شود .</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="71"/>
        <source>Effect Mode: Have a delicate experience. Normal Mode: Enjoy the fast performance</source>
        <translation>حالت افکت: یک تجربه ظریف داشته باشید. حالت عادی: از عملکرد سریع لذت ببرید</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="64"/>
        <source>Friendly Reminder</source>
        <translation>یادآور دوستانه</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="37"/>
        <source>Kindly Reminder</source>
        <translation>یادآور مهربان</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="38"/>
        <source>This application cannot run without window effect</source>
        <translation>این برنامه بدون افکت پنجره قابل اجرا نیست</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="42"/>
        <source>OK</source>
        <translation>تایید</translation>
    </message>
</context>
<context>
    <name>Window</name>
    <message>
        <location filename="../dde-lowpower/window.cpp" line="39"/>
        <source>Low battery, please plug in</source>
        <translation>باتری شما کم است ، دستگاه را برق وصل کنید</translation>
    </message>
</context>
<context>
    <name>PinCodeDialog</name>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="43"/>
        <source>The PIN for connecting to the Bluetooth device is:</source>
        <translation>PIN اتصال به دستگاه بلوتوث این است :</translation>
    </message>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="51"/>
        <source>Cancel</source>
        <translation>انصراف</translation>
    </message>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="53"/>
        <source>Confirm</source>
        <translation>تایید</translation>
    </message>
</context>
</TS>
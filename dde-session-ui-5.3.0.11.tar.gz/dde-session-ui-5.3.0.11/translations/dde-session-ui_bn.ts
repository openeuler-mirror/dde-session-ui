<?xml version="1.0" ?><!DOCTYPE TS><TS language="bn" sourcelanguage="en" version="2.1">
<context>
    <name>BubbleItem</name>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="181"/>
        <source>Just Now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="185"/>
        <source>%1 minutes ago</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="188"/>
        <source>%1 hours ago</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="192"/>
        <source>Yesterday </source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Content</name>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="32"/>
        <source>Chinese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="33"/>
        <source>English</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="44"/>
        <source>Cancel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="45"/>
        <source>Confirm</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="330"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="367"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="391"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="527"/>
        <source>Shut down</source>
        <translation>বন্ধ করুন</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="332"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="369"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="396"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="530"/>
        <source>Reboot</source>
        <translation>পুনঃরায় চালু করুন</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="392"/>
        <source>Are you sure you want to shut down?</source>
        <translation>আপনি কি নিশ্চিত যে, আপনি বন্ধ করতে চান?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="397"/>
        <source>Are you sure you want to reboot?</source>
        <translation>আপনি কি নিশ্চিত যে, আপনি পুনরায় চালু করতে চান?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="338"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="401"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="542"/>
        <source>Log out</source>
        <translation>লগ আউট করুন</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="402"/>
        <source>Are you sure you want to log out?</source>
        <translation>আপনি কি নিশ্চিত যে, আপনি লগ আউট করতে চান?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="334"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="533"/>
        <source>Suspend</source>
        <translation>সাময়িক ভাবে বন্ধ করুন</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="326"/>
        <source>The programs are preventing the computer from shutting down / hibernation, and forcing shut down / hibernate may cause data loss.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="327"/>
        <source>To close the program, Click Cancel, and then close the program.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="336"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="536"/>
        <source>Hibernate</source>
        <translation>হায়বারনেট</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="539"/>
        <source>Lock</source>
        <translation>লক করুন</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="546"/>
        <source>Switch user</source>
        <translation>ব্যবহারকারী পরিবর্তন করুন</translation>
    </message>
</context>
<context>
    <name>DMemoryWarningDialog</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="49"/>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="86"/>
        <source>Cancel</source>
        <translation>বাতিল</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="51"/>
        <source>Release</source>
        <translation>মুক্তি</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="54"/>
        <source>This application will be ended, please make sure your data has been saved!</source>
        <translation>এই অ্যাপ্লিকেশনটি শেষ হবে, দয়া করে নিশ্চিত করুন যে আপনার ডেটা সংরক্ষণ করা হয়েছে!</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="55"/>
        <source>Please save your document, text and spreadsheet</source>
        <translation>আপনার ডকুমেন্ট, টেক্সট এবং স্প্রেডশীট সংরক্ষণ করুন</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="87"/>
        <source>Continue</source>
        <translation>চালিয়ে যান</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="105"/>
        <source>Insufficient system memory, please end some applications to avoid getting stuck.</source>
        <translation>অপর্যাপ্ত সিস্টেম মেমরি, আটকে থাকা এড়াতে দয়া করে কিছু অ্যাপ্লিকেশন বন্ধ করুন।</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="217"/>
        <source>Continue to run %1, %2MB memory is required</source>
        <translation>%1 চালানো চালিয়ে যান, %2MB মেমরি প্রয়োজন</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="220"/>
        <source>Continue to open browser tab, %1MB memory is required</source>
        <translation>ব্রাউজার ট্যাব খোলা চালিয়ে যান, %1MB মেমরি প্রয়োজন</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="223"/>
        <source>To continue the operation, %1MB memory is required</source>
        <translation>অপারেশনটি চালিয়ে যেতে, %1MB মেমরি প্রয়োজন</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="229"/>
        <source>Your current memory is sufficient enough, continue to run %1?</source>
        <translation>আপনার বর্তমান মেমরি যথেষ্ট, %1 চালানো চালিয়ে যেতে চান?</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="232"/>
        <source>Your current memory is sufficient enough, continue to open browser tab?</source>
        <translation>আপনার বর্তমান মেমরি যথেষ্ট, ব্রাউজার ট্যাব খোলা চালিয়ে যেতে চান?</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="235"/>
        <source>Your current memory is sufficient enough, continue the operation?</source>
        <translation>আপনার বর্তমান মেমরি যথেষ্ট, অপারেশানটি চালিয়ে যেতে চান?</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="30"/>
        <source>Updates downloaded, restart to update?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="33"/>
        <source>Remind Later</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="34"/>
        <source>Not Now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="35"/>
        <source>Update Now</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DisplayModeProvider</name>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="176"/>
        <source>Duplicate</source>
        <translation>নকল</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="178"/>
        <source>Extend</source>
        <translation>প্রসারিত করুন</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="54"/>
        <source>Please don&apos;t power off or unplug your machine</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="136"/>
        <source>Installing updates %1%, please wait...</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>GreeterWorkek</name>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="93"/>
        <source>Domain account</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="249"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="264"/>
        <source>Failed to match fingerprint</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="282"/>
        <source>Wrong Password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="287"/>
        <source>The domain account or password is not correct. Please enter again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>InhibitWarnView</name>
    <message>
        <location filename="../dde-shutdown/view/inhibitwarnview.cpp" line="66"/>
        <source>Cancel</source>
        <translation>বাতিল</translation>
    </message>
</context>
<context>
    <name>KBLayoutIndicator</name>
    <message>
        <location filename="../dde-osd/kblayoutindicator.cpp" line="159"/>
        <source>Add keyboard layout</source>
        <translation>কীবোর্ড লেআউট যোগ করুন</translation>
    </message>
</context>
<context>
    <name>LockWorker</name>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="98"/>
        <source>Domain account</source>
        <translation>ডোমেন অ্যাকাউন্ট</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="221"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>আঙুলের ছাপ যাচাই করার সময় শেষ, দয়া করে হাত দিয়ে পাসওয়ার্ড প্রবেশ করান।</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="239"/>
        <source>Failed to match fingerprint</source>
        <translation>আঙুলের ছাপ মিলাতে ব্যর্থ হয়েছে</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="274"/>
        <source>Wrong Password</source>
        <translation>ভুল পাসওয়ার্ড</translation>
    </message>
</context>
<context>
    <name>MultiUsersWarningView</name>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="44"/>
        <source>Cancel</source>
        <translation>বাতিল</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="129"/>
        <source>The above users are still logged in and data will be lost due to reboot, are you sure you want to reboot?</source>
        <translation>উপরে থাকা ব্যবহারকারীরা এখনও লগ ইন করে আছেন এবং বন্ধ হওয়ার কারণে ডেটা হারিয়ে যাবে, আপনি কি নিশ্চিত যে আপনি পুনরায় চালু করতে চান?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="123"/>
        <source>The above users are still logged in and data will be lost due to shutdown, are you sure you want to shut down?</source>
        <translation>উপরে থাকা ব্যবহারকারীরা এখনও লগ ইন করে আছেন এবং বন্ধ হওয়ার কারণে ডেটা হারিয়ে যাবে, আপনি কি নিশ্চিত যে, আপনি বন্ধ করতে চান?</translation>
    </message>
</context>
<context>
    <name>NetworkSecretDialog</name>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="46"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="52"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="62"/>
        <source>Password</source>
        <translation>পাসওয়ার্ড</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="47"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="48"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="49"/>
        <source>Key</source>
        <translation>চাবি</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="50"/>
        <source>key</source>
        <translation>চাবি</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="58"/>
        <source>Private Pwd</source>
        <translation>ব্যক্তিগত Pwd</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="61"/>
        <source>Proxy Password</source>
        <translation>প্রক্সি পাসওয়ার্ড</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="63"/>
        <source>Group Password</source>
        <translation>গ্রুপ পাসওয়ার্ড</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="98"/>
        <source>Password required to connect &lt;font color=&quot;%1&quot;&gt;%2&lt;/font&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="167"/>
        <source>Wrong password, please enter again!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="107"/>
        <source>Cancel</source>
        <translation>বাতিল করুন</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="107"/>
        <source>Connect</source>
        <translation>সংযোগ</translation>
    </message>
</context>
<context>
    <name>NotificationsPlugin</name>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="71"/>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="94"/>
        <source>Notification Center</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="92"/>
        <source>%1 Notifications</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>NotifyCenterWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifycenterwidget.cpp" line="90"/>
        <source>Notification Center</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>NotifyWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifywidget.cpp" line="40"/>
        <source>No system notifications</source>
        <translation>কোনও সিস্টেম বিজ্ঞপ্তি নেই</translation>
    </message>
</context>
<context>
    <name>OSDProvider</name>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="43"/>
        <source>Window effect enabled</source>
        <translation>উইন্ডো ইফেক্ট চালু করা হয়েছে</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="44"/>
        <source>Window effect disabled</source>
        <translation>উইন্ডো ইফেক্ট বন্ধ করা হয়েছে</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="45"/>
        <source>Failed to enable window effects</source>
        <translation>উইন্ডো ইফেক্ট চালু করতে ব্যর্থ হয়েছে</translation>
    </message>
</context>
<context>
    <name>ProcessInfoModel</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/processinfomodel.cpp" line="111"/>
        <source>End</source>
        <translation>শেষ</translation>
    </message>
</context>
<context>
    <name>ShutdownWidget</name>
    <message>
        <source>Shut down</source>
        <translation type="vanished">বন্ধ করুন</translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="vanished">লগইন করুন</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation type="vanished">পুনঃরায় চালু করুন</translation>
    </message>
    <message>
        <source>Suspend</source>
        <translation type="vanished">সাময়িক ভাবে বন্ধ করুন</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation type="vanished">হায়বারনেট</translation>
    </message>
</context>
<context>
    <name>SuspendDialog</name>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="35"/>
        <source>External monitor detected, suspend?</source>
        <translation>বহিরাগত মনিটর সনাক্ত করা হয়েছে, সাময়িকভাবে বন্ধ করবেন?</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="35"/>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="57"/>
        <source>%1s</source>
        <translation>%1s</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="46"/>
        <source>Cancel</source>
        <translation>বাতিল</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="46"/>
        <source>Suspend</source>
        <translation>সাময়িক ভাবে বন্ধ করুন</translation>
    </message>
</context>
<context>
    <name>SystemMonitor</name>
    <message>
        <location filename="../dde-shutdown/view/systemmonitor.cpp" line="45"/>
        <source>Start system monitor</source>
        <translation>সিস্টেম মনিটর চালু করুন</translation>
    </message>
</context>
<context>
    <name>TimeWidget</name>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="69"/>
        <source>hh:mm</source>
        <translation>hh:mm</translation>
    </message>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="70"/>
        <source>yyyy-MM-dd dddd</source>
        <translation>yyyy-MM-dd dddd</translation>
    </message>
</context>
<context>
    <name>UpdateContent</name>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="44"/>
        <source>Welcome, system updated successfully</source>
        <translation>স্বাগতম, সফলভাবে আপডেট হয়েছে</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="45"/>
        <source>Current Edition:</source>
        <translation>বর্তমান সংস্করণঃ</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="46"/>
        <source>Enter</source>
        <translation>প্রবেশ করুন</translation>
    </message>
</context>
<context>
    <name>UserInputWidget</name>
    <message>
        <source>Login</source>
        <translation type="vanished">লগইন করুন</translation>
    </message>
    <message numerus="yes">
        <source>Please try again %n minute(s) later</source>
        <translation type="vanished"><numerusform>দয়া করে %n minutes(s) পরে চেষ্টা করুন</numerusform><numerusform>দয়া করে %n minutes(s) পরে চেষ্টা করুন</numerusform></translation>
    </message>
    <message>
        <source>Enter your password to shut down</source>
        <translation type="vanished">বন্ধ করতে আপনার পাসওয়ার্ড প্রবেশ করান</translation>
    </message>
    <message>
        <source>Enter your password to reboot</source>
        <translation type="vanished">রিস্টার্ট করতে আপনার পাসওয়ার্ড প্রবেশ করান</translation>
    </message>
</context>
<context>
    <name>WMChooser</name>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="57"/>
        <source>Effect Mode</source>
        <translation>ইফেক্ট মোড</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="60"/>
        <source>Normal Mode</source>
        <translation>সাধারণ মোড</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="68"/>
        <source>It has detected that you are using a virtual machine, which will affect the system performance and operation experience, for a smooth experience, Normal Mode is recommended</source>
        <translation>সিস্টেম সনাক্ত করেছে যে আপনি একটি ভার্চুয়াল মেশিন ব্যবহার করছেন, যা সিস্টেমের পারফরম্যান্স এবং অপারেশনের অভিজ্ঞতা প্রভাবিত করবে। একটি মসৃণ অভিজ্ঞতার জন্য, সাধারণ মোড নির্বাচন করার সুপারিশ করা হয়।</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="71"/>
        <source>Effect Mode: Have a delicate experience. Normal Mode: Enjoy the fast performance</source>
        <translation>ইফেক্ট মোড: একটি সূক্ষ্ম অভিজ্ঞতা আছে। সাধারণ মোড: দ্রুত কর্মক্ষমতা উপভোগ করুন।</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="64"/>
        <source>Friendly Reminder</source>
        <translation>বন্ধুত্বপূর্ণ অনুস্মারক</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="37"/>
        <source>Kindly Reminder</source>
        <translation>সদয় অনুস্মারক</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="38"/>
        <source>This application cannot run without window effect</source>
        <translation>এই অ্যাপ্লিকেশন উইন্ডো ইফেক্ট ছাড়া চালানো যাবে না</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="42"/>
        <source>OK</source>
        <translation>ঠিক আছে</translation>
    </message>
</context>
<context>
    <name>Window</name>
    <message>
        <location filename="../dde-lowpower/window.cpp" line="39"/>
        <source>Low battery, please plug in</source>
        <translation>ব্যাটারি কম, অনুগ্রহ করে চার্জার সংযুক্ত করুন</translation>
    </message>
</context>
</TS>
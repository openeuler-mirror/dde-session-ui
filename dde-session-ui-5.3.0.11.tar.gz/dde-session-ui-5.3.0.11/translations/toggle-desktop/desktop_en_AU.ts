<?xml version="1.0" ?><!DOCTYPE TS><TS language="en_AU" version="2.1">
    <context>
        <name>desktop</name>
        <message>
            <location filename="Desktop Entry]GenericName" line="0"/>
            <location filename="Desktop Entry]Name" line="0"/>
            <source>Show Desktop</source>
            <translation>Show Desktop</translation>
        </message>
        <message>
            <location filename="Desktop Entry]Comment" line="0"/>
            <source>Show desktop or show windows</source>
            <translation type="unfinished"/>
        </message>
    </context>
</TS>
<?xml version="1.0" ?><!DOCTYPE TS><TS language="ug" version="2.1">
    <context>
        <name>desktop</name>
        <message>
            <location filename="Desktop Entry]GenericName" line="0"/>
            <location filename="Desktop Entry]Name" line="0"/>
            <source>Show Desktop</source>
            <translation>ئۈستەل يۈزىنى كۆرۈش</translation>
        </message>
        <message>
            <location filename="Desktop Entry]Comment" line="0"/>
            <source>Show desktop or show windows</source>
            <translation>ئۈستەل يۈزى ياكى كۆزنەكنى كۆرۈش</translation>
        </message>
    </context>
</TS>
<?xml version="1.0" ?><!DOCTYPE TS><TS language="gl_ES" sourcelanguage="en" version="2.1">
<context>
    <name>Bubble</name>
    <message>
        <location filename="../dde-osd/notification/bubble.cpp" line="309"/>
        <source>1 new message</source>
        <translation>1 nova mensaxe</translation>
    </message>
</context>
<context>
    <name>BubbleItem</name>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="198"/>
        <source>Just Now</source>
        <translation>Só agora</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="200"/>
        <source>%1 minutes ago</source>
        <translation>%1 minutos atrás</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="202"/>
        <source>%1 hours ago</source>
        <translation>%1 horas atrás</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="205"/>
        <source>Yesterday </source>
        <translation>Onte</translation>
    </message>
</context>
<context>
    <name>Content</name>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="224"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="225"/>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
</context>
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="330"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="367"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="391"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="527"/>
        <source>Shut down</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="332"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="369"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="396"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="530"/>
        <source>Reboot</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="392"/>
        <source>Are you sure you want to shut down?</source>
        <translation>Está seguro de que quere apagalo?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="397"/>
        <source>Are you sure you want to reboot?</source>
        <translation>Está seguro de que quere reiniciar?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="338"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="401"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="542"/>
        <source>Log out</source>
        <translation>Pechar a sesión</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="402"/>
        <source>Are you sure you want to log out?</source>
        <translation>Está seguro de que quere pechar sesión?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="334"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="533"/>
        <source>Suspend</source>
        <translation>Suspender</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="326"/>
        <source>The programs are preventing the computer from shutting down / hibernation, and forcing shut down / hibernate may cause data loss.</source>
        <translation>Os programas están impedindo que o ordenador se apague / hiberne e forzar a apagar / hibernar pode causar perda de datos.</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="327"/>
        <source>To close the program, Click Cancel, and then close the program.</source>
        <translation>Para pechar o programa, prema en Cancelar e logo peche o programa.</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="336"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="536"/>
        <source>Hibernate</source>
        <translation>Hibernar</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="539"/>
        <source>Lock</source>
        <translation>Bloquear</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="546"/>
        <source>Switch user</source>
        <translation>Cambiar de usuario</translation>
    </message>
</context>
<context>
    <name>DMemoryWarningDialog</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="49"/>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="86"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="51"/>
        <source>Release</source>
        <translation>Liberar</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="54"/>
        <source>This application will be ended, please make sure your data has been saved!</source>
        <translation>Este aplicativo pecharase, asegúrate de gardar os teus datos.</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="55"/>
        <source>Please save your document, text and spreadsheet</source>
        <translation>Garda o documento, texto e folla de cálculo</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="87"/>
        <source>Continue</source>
        <translation>Continuar</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="105"/>
        <source>Insufficient system memory, please end some applications to avoid getting stuck.</source>
        <translation>Memoria do sistema insuficiente, finalice algúns aplicativos para evitar atascos.</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="217"/>
        <source>Continue to run %1, %2MB memory is required</source>
        <translation>Continúa executando% 1, memoria 2MB é necesaria</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="220"/>
        <source>Continue to open browser tab, %1MB memory is required</source>
        <translation>Continúa abrindo a lapela do navegador, é necesaria a memoria% 1 MB</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="223"/>
        <source>To continue the operation, %1MB memory is required</source>
        <translation>Para continuar a operación, é necesaria unha memoria de % 1MB</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="229"/>
        <source>Your current memory is sufficient enough, continue to run %1?</source>
        <translation>A túa memoria actual é suficiente, continuar executando% 1?</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="232"/>
        <source>Your current memory is sufficient enough, continue to open browser tab?</source>
        <translation>A túa memoria actual é suficiente, continúa abrindo a lapela do navegador?</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="235"/>
        <source>Your current memory is sufficient enough, continue the operation?</source>
        <translation>A túa memoria actual é suficiente, continúa coa operación?</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="30"/>
        <source>Updates downloaded, restart to update?</source>
        <translation>Actualizacións descargadas, reiniciar para actualizar?</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="33"/>
        <source>Remind Later</source>
        <translation>Lembrar máis tarde</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="34"/>
        <source>Not Now</source>
        <translation>Agora non</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="35"/>
        <source>Update Now</source>
        <translation>Actualizar agora</translation>
    </message>
</context>
<context>
    <name>DisplayModeProvider</name>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="264"/>
        <source>Customize</source>
        <translation>Personalización</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="266"/>
        <source>Duplicate</source>
        <translation>Duplicar</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="268"/>
        <source>Extend</source>
        <translation>Extender</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="54"/>
        <source>Please don&apos;t power off or unplug your machine</source>
        <translation>Por favor, non apagues ou desconectes da corrente o computador</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="136"/>
        <source>Installing updates %1%, please wait...</source>
        <translation>Instalando actualizacións %1%, por favor agarda...</translation>
    </message>
</context>
<context>
    <name>GreeterWorkek</name>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="93"/>
        <source>Domain account</source>
        <translation>Conta do dominio</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="249"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>Rematou o tempo de verificación de pegadas dixitais. Introduce o seu contrasinal manualmente</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="264"/>
        <source>Failed to match fingerprint</source>
        <translation>Erro ao coincidir as pegadas dixitais</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="282"/>
        <source>Wrong Password</source>
        <translation>Contrasinal non válido</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="287"/>
        <source>The domain account or password is not correct. Please enter again.</source>
        <translation>A conta ou contrasinal de dominio non é correcta. Introduce de novo.</translation>
    </message>
</context>
<context>
    <name>InhibitWarnView</name>
    <message>
        <location filename="../dde-shutdown/view/inhibitwarnview.cpp" line="66"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>KBLayoutIndicator</name>
    <message>
        <location filename="../dde-osd/kblayoutindicator.cpp" line="159"/>
        <source>Add keyboard layout</source>
        <translation>Engadir disposición do teclado</translation>
    </message>
</context>
<context>
    <name>LockWorker</name>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="98"/>
        <source>Domain account</source>
        <translation>Conta do dominio</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="221"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>Rematou o tempo de verificación de pegadas dixitais. Introduce o seu contrasinal manualmente</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="239"/>
        <source>Failed to match fingerprint</source>
        <translation>Erro ao coincidir as pegadas dixitais</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="274"/>
        <source>Wrong Password</source>
        <translation>Contrasinal non válido</translation>
    </message>
</context>
<context>
    <name>MultiUsersWarningView</name>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="44"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="129"/>
        <source>The above users are still logged in and data will be lost due to reboot, are you sure you want to reboot?</source>
        <translation>Os usuarios anteriores seguen conectados e os datos perderanse por reiniciar. Estás seguro de que queres reiniciar?</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="123"/>
        <source>The above users are still logged in and data will be lost due to shutdown, are you sure you want to shut down?</source>
        <translation>Os usuarios anteriores aínda están conectados e os datos perdéranse por apagado, está seguro de que desexa pechar?</translation>
    </message>
</context>
<context>
    <name>NetworkSecretDialog</name>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="46"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="52"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="62"/>
        <source>Password</source>
        <translation>Contrasinal</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="47"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="48"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="49"/>
        <source>Key</source>
        <translation>Chave</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="50"/>
        <source>key</source>
        <translation>clave</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="58"/>
        <source>Private Pwd</source>
        <translation>Contrasinal privado</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="61"/>
        <source>Proxy Password</source>
        <translation>Contrasinal de proxy</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="63"/>
        <source>Group Password</source>
        <translation>Contrasinal do grupo</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="105"/>
        <source>Password required to connect &lt;font color=&quot;%1&quot;&gt;%2&lt;/font&gt;</source>
        <translation>Requírese contrasinal para conectar a &lt;font color=&quot;%1&quot;&gt;%2&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="174"/>
        <source>Wrong password, please enter again!</source>
        <translation>Contrasinal incorrecto, por favor ingresa de novo.</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="114"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="114"/>
        <source>Connect</source>
        <translation>Conectar</translation>
    </message>
</context>
<context>
    <name>NotificationsPlugin</name>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="67"/>
        <source>Notification Center</source>
        <translation>Centro de notificación</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="87"/>
        <source>%1 Notifications</source>
        <translation>%1 notificacións</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="89"/>
        <source>No messages</source>
        <translation>Non hai ningunha mensaxe</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="255"/>
        <source>Turn off DND mode</source>
        <translation>Apagar o modo DND</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="255"/>
        <source>Turn on DND mode</source>
        <translation>Acender o modo DND</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="262"/>
        <source>Notification settings</source>
        <translation>Configuración das notificacións</translation>
    </message>
</context>
<context>
    <name>NotifyCenterWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifycenterwidget.cpp" line="88"/>
        <source>Notification Center</source>
        <translation>Centro de notificación</translation>
    </message>
</context>
<context>
    <name>NotifyWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifywidget.cpp" line="40"/>
        <source>No system notifications</source>
        <translation>Sen notificacións</translation>
    </message>
</context>
<context>
    <name>OSDProvider</name>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="47"/>
        <source>Window effect enabled</source>
        <translation>Efecto da xanela activado</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="48"/>
        <source>Window effect disabled</source>
        <translation>Efecto da xanela desactivado</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="49"/>
        <source>Failed to enable window effects</source>
        <translation>Non foi posible activar os efectos das xanelas</translation>
    </message>
</context>
<context>
    <name>ProcessInfoModel</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/processinfomodel.cpp" line="111"/>
        <source>End</source>
        <translation>Fin</translation>
    </message>
</context>
<context>
    <name>SuspendDialog</name>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="39"/>
        <source>External monitor detected, suspend?</source>
        <translation>Monitor externo detectado, suspender?</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="39"/>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="61"/>
        <source>%1s</source>
        <translation>%1s</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="50"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="50"/>
        <source>Suspend</source>
        <translation>Suspender</translation>
    </message>
</context>
<context>
    <name>SystemMonitor</name>
    <message>
        <location filename="../dde-shutdown/view/systemmonitor.cpp" line="45"/>
        <source>Start system monitor</source>
        <translation>Comezar o sistema do monitor</translation>
    </message>
</context>
<context>
    <name>TimeWidget</name>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="69"/>
        <source>hh:mm</source>
        <translation> hh:mm </translation>
    </message>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="70"/>
        <source>yyyy-MM-dd dddd</source>
        <translation>dddd dd-MM-yyyy</translation>
    </message>
</context>
<context>
    <name>TouchscreenSetting</name>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="45"/>
        <source>Select your touch screen</source>
        <translation>Seleccionar o tacto da pantalla</translation>
    </message>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="51"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="52"/>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
</context>
<context>
    <name>UpdateContent</name>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="44"/>
        <source>Welcome, system updated successfully</source>
        <translation>Benvido/a, o sistema actualizouse con éxito</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="45"/>
        <source>Current Edition:</source>
        <translation>Edición actual:</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="46"/>
        <source>Enter</source>
        <translation>Inserir</translation>
    </message>
</context>
<context>
    <name>WMChooser</name>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="57"/>
        <source>Effect Mode</source>
        <translation>Modo de efecto</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="60"/>
        <source>Normal Mode</source>
        <translation>Modo normal</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="68"/>
        <source>It has detected that you are using a virtual machine, which will affect the system performance and operation experience, for a smooth experience, Normal Mode is recommended</source>
        <translation>Detectou que está a usar unha máquina virtual, o que afectará o rendemento do sistema e a súa experiencia de funcionamento. Para unha experiencia sen problemas, recoméndase o modo normal</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="71"/>
        <source>Effect Mode: Have a delicate experience. Normal Mode: Enjoy the fast performance</source>
        <translation>Modo Efecto: ten unha experiencia delicada. Modo normal: goza do rápido rendemento</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="64"/>
        <source>Friendly Reminder</source>
        <translation>Recordatorio amigable</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="37"/>
        <source>Kindly Reminder</source>
        <translation>Recordatorio</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="38"/>
        <source>This application cannot run without window effect</source>
        <translation>Este aplicativo non se pode executar sen efecto xanela</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="42"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>Window</name>
    <message>
        <location filename="../dde-lowpower/window.cpp" line="39"/>
        <source>Low battery, please plug in</source>
        <translation>Batería baixa, por favor conecta á corrente</translation>
    </message>
</context>
<context>
    <name>PinCodeDialog</name>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="43"/>
        <source>The PIN for connecting to the Bluetooth device is:</source>
        <translation>O PIN para ligar co dispositivo Bluetooth é:</translation>
    </message>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="51"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="53"/>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
</context>
</TS>
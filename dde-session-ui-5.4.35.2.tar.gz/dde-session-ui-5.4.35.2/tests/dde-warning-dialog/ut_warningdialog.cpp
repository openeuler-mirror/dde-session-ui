#include "warningdialog.h"

#include <gtest/gtest.h>

class UT_WarningDialog : public testing::Test
{

};

TEST_F(UT_WarningDialog, coverageTest)
{
    WarningDialog widget;
}

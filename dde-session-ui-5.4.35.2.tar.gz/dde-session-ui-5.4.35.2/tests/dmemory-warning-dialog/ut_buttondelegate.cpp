#include "buttondelegate.h"

#include <gtest/gtest.h>

class Ut_ButtonDelegate : public testing::Test
{

};

TEST_F(Ut_ButtonDelegate, coverageTest)
{
    ButtonDelegate buttonDelegate;
}

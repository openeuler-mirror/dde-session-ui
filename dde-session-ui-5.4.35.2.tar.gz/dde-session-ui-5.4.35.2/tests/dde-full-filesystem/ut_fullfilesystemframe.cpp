#include "fullfilesystemframe.h"


#include <gtest/gtest.h>


class UT_FullFileSystemFrame : public testing::Test
{

};

TEST_F(UT_FullFileSystemFrame, coverageTest)
{
    FullFilesystemFrame frame;
}

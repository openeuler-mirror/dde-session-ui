<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_HK" sourcelanguage="en" version="2.1">
<context>
    <name>Bubble</name>
    <message>
        <location filename="../dde-osd/notification/bubble.cpp" line="309"/>
        <source>1 new message</source>
        <translation>1條新消息</translation>
    </message>
</context>
<context>
    <name>BubbleItem</name>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="221"/>
        <source>Just Now</source>
        <translation>剛剛</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="223"/>
        <source>%1 minutes ago</source>
        <translation>%1分鐘前</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="225"/>
        <source>%1 hours ago</source>
        <translation>%1小時前</translation>
    </message>
    <message>
        <location filename="../dde-osd/notification-center/bubbleitem.cpp" line="228"/>
        <source>Yesterday </source>
        <translation>昨天</translation>
    </message>
</context>
<context>
    <name>Content</name>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="228"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../dde-license-dialog/content.cpp" line="229"/>
        <source>Confirm</source>
        <translation>確定</translation>
    </message>
</context>
<context>
    <name>ContentWidget</name>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="330"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="367"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="391"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="527"/>
        <source>Shut down</source>
        <translation>關機</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="332"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="369"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="396"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="530"/>
        <source>Reboot</source>
        <translation>重新啟動</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="392"/>
        <source>Are you sure you want to shut down?</source>
        <translation>您確定要關機嗎？</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="397"/>
        <source>Are you sure you want to reboot?</source>
        <translation>您確定要重啟嗎？</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="338"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="401"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="542"/>
        <source>Log out</source>
        <translation>註銷</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="402"/>
        <source>Are you sure you want to log out?</source>
        <translation>您確定要註銷嗎？</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="334"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="533"/>
        <source>Suspend</source>
        <translation>待機</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="326"/>
        <source>The programs are preventing the computer from shutting down / hibernation, and forcing shut down / hibernate may cause data loss.</source>
        <translation>以上程序阻止關機/休眠，強制關機/休眠可能會導致其數據丟失。</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="327"/>
        <source>To close the program, Click Cancel, and then close the program.</source>
        <translation>您可以點擊“取消”然後關閉這些程序。</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="336"/>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="536"/>
        <source>Hibernate</source>
        <translation>休眠</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="539"/>
        <source>Lock</source>
        <translation>鎖定</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/contentwidget.cpp" line="546"/>
        <source>Switch user</source>
        <translation>切換使用者</translation>
    </message>
</context>
<context>
    <name>DMemoryWarningDialog</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="49"/>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="86"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="51"/>
        <source>Release</source>
        <translation>釋放</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="54"/>
        <source>This application will be ended, please make sure your data has been saved!</source>
        <translation>應用內存將被釋放，請確認當前數據是否已保存！</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="55"/>
        <source>Please save your document, text and spreadsheet</source>
        <translation>如文檔、文本、表單等數據</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="87"/>
        <source>Continue</source>
        <translation>繼續</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="105"/>
        <source>Insufficient system memory, please end some applications to avoid getting stuck.</source>
        <translation>當前系統內存不足，避免出現卡死，請釋放相關應用內存！</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="217"/>
        <source>Continue to run %1, %2MB memory is required</source>
        <translation>如果繼續運行%1應用，需要釋放%2MB內存！</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="220"/>
        <source>Continue to open browser tab, %1MB memory is required</source>
        <translation>如果繼續打開瀏覽器標籤，需要釋放%1MB內存！</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="223"/>
        <source>To continue the operation, %1MB memory is required</source>
        <translation>如果繼續執行命令，需要釋放%1MB內存！</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="229"/>
        <source>Your current memory is sufficient enough, continue to run %1?</source>
        <translation>您的當前內存已滿足使用，是否繼續運行%1應用？</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="232"/>
        <source>Your current memory is sufficient enough, continue to open browser tab?</source>
        <translation>您的當前內存已滿足使用，是否繼續打開瀏覽器標籤？</translation>
    </message>
    <message>
        <location filename="../dmemory-warning-dialog/src/dmemorywarningdialog.cpp" line="235"/>
        <source>Your current memory is sufficient enough, continue the operation?</source>
        <translation>您的當前內存已滿足使用，是否繼續執行命令？</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="30"/>
        <source>Updates downloaded, restart to update?</source>
        <translation>更新已經下載完畢， 需要重啟以完成更新， 是否需要更新？</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="33"/>
        <source>Remind Later</source>
        <translation>稍後提醒</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="34"/>
        <source>Not Now</source>
        <translation>暫不更新</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/dialog.cpp" line="35"/>
        <source>Update Now</source>
        <translation>立即更新</translation>
    </message>
</context>
<context>
    <name>DisplayModeProvider</name>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="249"/>
        <source>Only on %1</source>
        <translation>僅%1屏</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="251"/>
        <source>Duplicate</source>
        <translation>同步</translation>
    </message>
    <message>
        <location filename="../dde-osd/displaymodeprovider.cpp" line="253"/>
        <source>Extend</source>
        <translation>延伸</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="54"/>
        <source>Please don&apos;t power off or unplug your machine</source>
        <translation>請不要拔掉電源或強行關機</translation>
    </message>
    <message>
        <location filename="../dde-offline-upgrader/frame.cpp" line="136"/>
        <source>Installing updates %1%, please wait...</source>
        <translation>正在安裝更新%1%，請稍候......</translation>
    </message>
</context>
<context>
    <name>GreeterWorkek</name>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="93"/>
        <source>Domain account</source>
        <translation>域帳戶</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="249"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>指紋密碼驗證超時，請手動輸入密碼</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="264"/>
        <source>Failed to match fingerprint</source>
        <translation>指紋解鎖失敗</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="282"/>
        <source>Wrong Password</source>
        <translation>密碼錯誤</translation>
    </message>
    <message>
        <location filename="../lightdm-deepin-greeter/greeterworkek.cpp" line="287"/>
        <source>The domain account or password is not correct. Please enter again.</source>
        <translation>域帳戶或域密碼不正確，請重新輸入。</translation>
    </message>
</context>
<context>
    <name>InhibitWarnView</name>
    <message>
        <location filename="../dde-shutdown/view/inhibitwarnview.cpp" line="66"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>KBLayoutIndicator</name>
    <message>
        <location filename="../dde-osd/kblayoutindicator.cpp" line="161"/>
        <source>Add keyboard layout</source>
        <translation>添加鍵盤佈局</translation>
    </message>
</context>
<context>
    <name>LockWorker</name>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="98"/>
        <source>Domain account</source>
        <translation>域帳戶</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="221"/>
        <source>Fingerprint verification timed out, please enter your password manually</source>
        <translation>指紋密碼驗證超時，請手動輸入密碼</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="239"/>
        <source>Failed to match fingerprint</source>
        <translation>指紋解鎖失敗</translation>
    </message>
    <message>
        <location filename="../dde-lock/lockworker.cpp" line="274"/>
        <source>Wrong Password</source>
        <translation>密碼錯誤</translation>
    </message>
</context>
<context>
    <name>MultiUsersWarningView</name>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="44"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="129"/>
        <source>The above users are still logged in and data will be lost due to reboot, are you sure you want to reboot?</source>
        <translation>此電腦還有以上帳戶在登錄，重啟電腦會導致其數據丟失，是否要重啟此電腦？</translation>
    </message>
    <message>
        <location filename="../dde-shutdown/view/multiuserswarningview.cpp" line="123"/>
        <source>The above users are still logged in and data will be lost due to shutdown, are you sure you want to shut down?</source>
        <translation>此電腦還有以上帳戶在登錄，關閉電腦會導致其數據丟失，是否要關閉此電腦？</translation>
    </message>
</context>
<context>
    <name>NetworkSecretDialog</name>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="46"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="52"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="62"/>
        <source>Password</source>
        <translation>密碼</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="47"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="48"/>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="49"/>
        <source>Key</source>
        <translation>金鑰</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="50"/>
        <source>key</source>
        <translation>金鑰</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="58"/>
        <source>Private Pwd</source>
        <translation>私鑰密碼</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="61"/>
        <source>Proxy Password</source>
        <translation>代理密碼</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="63"/>
        <source>Group Password</source>
        <translation>組密碼</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="105"/>
        <source>Password required to connect &lt;font color=&quot;%1&quot;&gt;%2&lt;/font&gt;</source>
        <translation>連接&lt;font color=&quot;%1&quot;&gt;%2&lt;/font&gt;需要密碼</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="174"/>
        <source>Wrong password, please enter again!</source>
        <translation>密碼錯誤，請再次輸入！</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="114"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../dnetwork-secret-dialog/networksecretdialog.cpp" line="114"/>
        <source>Connect</source>
        <translation>連接</translation>
    </message>
</context>
<context>
    <name>NotificationsPlugin</name>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="71"/>
        <source>Notification Center</source>
        <translation>通知中心</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="91"/>
        <source>%1 Notifications</source>
        <translation>%1條通知</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="93"/>
        <source>No messages</source>
        <translation>暫無新消息</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="239"/>
        <source>Turn off DND mode</source>
        <translation>關閉勿擾模式</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="239"/>
        <source>Turn on DND mode</source>
        <translation>開啟勿擾模式</translation>
    </message>
    <message>
        <location filename="../dde-notification-plugin/notifications/notificationsplugin.cpp" line="246"/>
        <source>Notification settings</source>
        <translation>通知設置</translation>
    </message>
</context>
<context>
    <name>NotifyCenterWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifycenterwidget.cpp" line="89"/>
        <source>Notification Center</source>
        <translation>通知中心</translation>
    </message>
</context>
<context>
    <name>NotifyWidget</name>
    <message>
        <location filename="../dde-osd/notification-center/notifywidget.cpp" line="40"/>
        <source>No system notifications</source>
        <translation>無系統通知</translation>
    </message>
</context>
<context>
    <name>OSDProvider</name>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="47"/>
        <source>Window effect enabled</source>
        <translation>窗口特效已開啟</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="48"/>
        <source>Window effect disabled</source>
        <translation>窗口特效已關閉</translation>
    </message>
    <message>
        <location filename="../dde-osd/osdprovider.cpp" line="49"/>
        <source>Failed to enable window effects</source>
        <translation>無法啟動視窗效果</translation>
    </message>
</context>
<context>
    <name>PinCodeDialog</name>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="39"/>
        <source>The PIN for connecting to the Bluetooth device is:</source>
        <translation>連接藍牙設備的PIN碼為：</translation>
    </message>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="47"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../dde-bluetooth-dialog/pincodedialog.cpp" line="49"/>
        <source>Confirm</source>
        <translation>確定</translation>
    </message>
</context>
<context>
    <name>ProcessInfoModel</name>
    <message>
        <location filename="../dmemory-warning-dialog/src/processinfomodel.cpp" line="111"/>
        <source>End</source>
        <translation>結束</translation>
    </message>
</context>
<context>
    <name>SuspendDialog</name>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="39"/>
        <source>External monitor detected, suspend?</source>
        <translation>檢測到外部顯示器，是否待機？</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="39"/>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="61"/>
        <source>%1s</source>
        <translation>%1秒</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="50"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../dde-suspend-dialog/suspenddialog.cpp" line="50"/>
        <source>Suspend</source>
        <translation>待機</translation>
    </message>
</context>
<context>
    <name>SystemMonitor</name>
    <message>
        <location filename="../dde-shutdown/view/systemmonitor.cpp" line="45"/>
        <source>Start system monitor</source>
        <translation>啟動系統監視器</translation>
    </message>
</context>
<context>
    <name>TimeWidget</name>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="69"/>
        <source>hh:mm</source>
        <translation>hh:mm</translation>
    </message>
    <message>
        <location filename="../dde-lock/timewidget.cpp" line="70"/>
        <source>yyyy-MM-dd dddd</source>
        <translation>yyyy-MM-dd dddd</translation>
    </message>
</context>
<context>
    <name>TouchscreenSetting</name>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="43"/>
        <source>Select your touch screen</source>
        <translation>選擇觸控屏</translation>
    </message>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="53"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../dde-touchscreen-dialog/touchscreensetting.cpp" line="54"/>
        <source>Confirm</source>
        <translation>確定</translation>
    </message>
</context>
<context>
    <name>UpdateContent</name>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="44"/>
        <source>Welcome, system updated successfully</source>
        <translation>歡迎您，系統已成功升級</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="45"/>
        <source>Current Edition:</source>
        <translation>當前版本：</translation>
    </message>
    <message>
        <location filename="../dde-welcome/updatecontent.cpp" line="46"/>
        <source>Enter</source>
        <translation>開始使用</translation>
    </message>
</context>
<context>
    <name>WMChooser</name>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="57"/>
        <source>Effect Mode</source>
        <translation>特效模式</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="60"/>
        <source>Normal Mode</source>
        <translation>普通模式</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="68"/>
        <source>It has detected that you are using a virtual machine, which will affect the system performance and operation experience, for a smooth experience, Normal Mode is recommended</source>
        <translation>檢測到您正在使用虛擬機，這將影響系統性能和操作體驗，為了在虛擬機下流暢地使用該系統，建議您選擇普通模式進入桌面</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="71"/>
        <source>Effect Mode: Have a delicate experience. Normal Mode: Enjoy the fast performance</source>
        <translation>特效模式：享受精緻美觀的體驗；普通模式：盡享流暢極速的性能</translation>
    </message>
    <message>
        <location filename="../dde-wm-chooser/wmchooser.cpp" line="64"/>
        <source>Friendly Reminder</source>
        <translation>友情提示</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="37"/>
        <source>Kindly Reminder</source>
        <translation>溫馨提示</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="38"/>
        <source>This application cannot run without window effect</source>
        <translation>此應用不支持在無窗口特效下運行</translation>
    </message>
    <message>
        <location filename="../dde-warning-dialog/warningdialog.cpp" line="42"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>Window</name>
    <message>
        <location filename="../dde-lowpower/window.cpp" line="39"/>
        <source>Low battery, please plug in</source>
        <translation>電量不足，請接入電源</translation>
    </message>
</context>
</TS>
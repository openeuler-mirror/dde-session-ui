<?xml version="1.0" ?><!DOCTYPE TS><TS language="sw" version="2.1">
    <context>
        <name>desktop</name>
        <message>
            <location filename="Desktop Entry]GenericName" line="0"/>
            <location filename="Desktop Entry]Name" line="0"/>
            <source>Show Desktop</source>
            <translation>Onesha eneo ya kazi</translation>
        </message>
        <message>
            <location filename="Desktop Entry]Comment" line="0"/>
            <source>Show desktop or show windows</source>
            <translation>Onesha eneo ya kazi ama onesha madirisha</translation>
        </message>
    </context>
</TS>